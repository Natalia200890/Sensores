package natalia.flores.tarea1_dama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnproximidad, btnluminoso;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnluminoso = findViewById(R.id.btnluminoso);

        btnproximidad = findViewById(R.id.btnproximidad);
        btnproximidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Enviar();}
        });

    btnluminoso = findViewById(R.id.btnluminoso);
        btnluminoso.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) { Enviarl();}
    });
}

       private void Enviar(){
            Intent miIntent = new Intent(MainActivity.this, SensorProximidad.class);
            startActivity(miIntent);

    }
    private void Enviarl(){
        Intent miIntent = new Intent(MainActivity.this, SensorLuminosidad.class);
        startActivity(miIntent);

    }
    }
